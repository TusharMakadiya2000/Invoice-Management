"use client";

import Sidebar from "@/components/common/sidebar";
import Header from "@/components/common/NavBar";
import { useSession } from "next-auth/react";
import UsersTable from "@/components/common/UsersTable";
const Dashboard = () => {
  // const session = await getServerSession(authOptions);
  const session = useSession();
  return (
    <>
      <div className="flex h-screen">
        <Sidebar />

        <div className="w-full dark:bg-fgc-dark">
          <Header />
          <div className="">
            <UsersTable data={[]} />
          </div>
        </div>
      </div>
    </>
  );
};

export default Dashboard;
