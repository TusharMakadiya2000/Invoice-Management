// \src\app\user\[[...userid]].page.tsx
"use client";
import React, { Fragment, useEffect, useState } from "react";
import axios from "axios";
import Header from "@/components/common/NavBar";
import Sidebar from "@/components/common/sidebar";
import SecurityDetails from "@/components/common/SecurityDetails";
import { useForm } from "react-hook-form";
import { useRouter } from "next/navigation";
import { yupResolver } from "@hookform/resolvers/yup";
import * as yup from "yup";
import { Input } from "@/components/common/Input";
import { SHA256 } from "crypto-js";
import { toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import Icon from "@/components/common/Icon";

interface Users {
  id?: string;
  fullName: string;
  businessName: string;
  email: string;
  servieCenterName: string;
  password?: string;
  confirmPassword?: string;
}

export default function Home({ params }: { params: { id: string } }) {
  console.log("params", params.id);
  const userId = params.id;
  console.log("userId", userId);
  const [itemId, setItemId] = useState<string>(params.id ? params.id[0] : "");
  const router = useRouter();
  const [userDetails, setUserDetails] = useState<Users[]>([]);
  const isEditMode = !!itemId;
  const [currentPassword, setCurrentPassword] = useState<string>("");

  const editModeValidationSchema = yup.object({
    fullName: yup.string().required("Full Name is required"),
    businessName: yup.string().required("Business Name is required"),
    email: yup.string().required("Email is required"),
    servieCenterName: yup.string().required("Servie Center Name is required"),
  });

  const saveModeValidationSchema = yup.object({
    fullName: yup.string().required("Full Name is required"),
    businessName: yup.string().required("Business Name is required"),
    email: yup.string().required("Email is required"),
    servieCenterName: yup.string().required("Servie Center Name is required"),
    password: yup
      .string()
      .required("Password is required")
      .min(8, "Password must be at least 8 characters")
      .matches(
        /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@])[a-zA-Z\d@]{8,}$/,
        "Password must contain at least one uppercase letter, one lowercase letter, and one number"
      ),
    confirmPassword: yup
      .string()
      .required("Confirm Password is required")
      .oneOf([yup.ref("password"), ""], "Passwords must match"),
  });

  const validationSchema = isEditMode
    ? editModeValidationSchema
    : saveModeValidationSchema;
  const {
    register,
    handleSubmit,
    setValue,
    getValues,
    trigger,
    formState: { errors },
  } = useForm<Users>({
    resolver: yupResolver(validationSchema),
    mode: "all",
  });
  useEffect(() => {
    // Fetch current password value on component mount
    getCurrentPasswordValue();
  }, []);
  const getCurrentPasswordValue = () => {
    const currentPasswordValue =
      getValues("currentPassword" as keyof Users) || "";
    console.log("currentPasswordValue", currentPasswordValue);
    setCurrentPassword(currentPasswordValue);
  };
  useEffect(() => {
    if (itemId) {
      axios.get(`/api/user/getuser?id=${itemId}`).then((response) => {
        const item = response.data;
        setValue("fullName", item.fullName);
        setValue("businessName", item.businessName);
        setValue("email", item.email);
        setValue("servieCenterName", item.servieCenterName);
        trigger();
      });
    } else {
      setValue("fullName", "");
      setValue("businessName", "");
      setValue("email", "");
      setValue("servieCenterName", "");
      setValue("password", "");
      setValue("confirmPassword", "");
    }
  }, [itemId]);

  const onSubmit = async (data: Users) => {
    const requestMethod = itemId ? "put" : "post";
    let url = itemId
      ? `/api/user/updateuser?id=${encodeURIComponent(itemId)}`
      : "/api/user/add";
    const hashedPassword = data.password ?? "";
    data.password = SHA256(hashedPassword).toString();

    // If it's an update (edit), send the ID in the request body
    const requestData = itemId ? { ...data, id: itemId } : data;
    console.log("requestData", requestData);
    console.log("requestData", requestData);
    axios[requestMethod]<Users>(url, requestData)
      .then((response) => {
        if (itemId) {
          const updatedItems = userDetails.map((userDetails) =>
            userDetails.id === itemId ? response.data : userDetails
          );
          setUserDetails(updatedItems);
          toast.success("User Update successfully!");
          // router.refresh();
        } else {
          // If adding, add the new item to the state
          setUserDetails([...userDetails, response.data]);
          toast.success("User save successfully!");
          // router.refresh();
        }
        // Clear the form after submission
        setValue("fullName", "");
        setValue("businessName", "");
        setValue("email", "");
        setValue("servieCenterName", "");
      })
      .catch((error) => {
        console.error("Error adding/updating item:", error.message);
      });
  };

  return (
    <>
      <form onSubmit={handleSubmit(onSubmit)}>
        <div className="flex">
          <Sidebar />
          <div className="w-full dark:bg-fgc-dark">
            <Header />
            <div className="flex justify-items-center place-items-center p-4">
              <div className="w-full p-6 shadow-lg bg-white rounded-md dark:bg-bgc-dark">
                <div className="flex items-center justify-between mb-3 border-b border-gray-200">
                  <div></div>
                  <h1 className="text-xl font-bold pb-3">
                    {itemId ? "Edit User" : "Add User"}
                  </h1>
                  <Icon
                    icon="x"
                    className="h-5 w-5 lg:h-8 lg:w-8 hover:cursor-pointer"
                    onClick={() => router.back()}
                  />
                </div>
                <h2 className="text-lg font-semibold mb-2">Personal Details</h2>

                <div className="flex flex-col gap-5">
                  <div className="flex justify-items-center gap-4">
                    <div className="w-full">
                      <Input
                        preIcon="pencil"
                        label="Full Name"
                        type="text"
                        placeholder="Enter Full Name"
                        name="fullName"
                        register={register}
                        error={errors?.fullName?.message?.toString()}
                      />
                    </div>
                    <div className="w-full">
                      <Input
                        preIcon="annotation"
                        label="Business Name"
                        type="text"
                        placeholder="Enter Business Name"
                        name="businessName"
                        register={register}
                        error={errors?.businessName?.message?.toString()}
                      />
                    </div>
                  </div>
                  <div className="flex justify-items-center gap-4">
                    <div className="w-full">
                      <Input
                        preIcon="mail"
                        label="Email"
                        type="email"
                        placeholder="Enter Your Email"
                        name="email"
                        register={register}
                        error={errors?.email?.message?.toString()}
                      />
                    </div>
                    <div className="w-full">
                      <Input
                        preIcon="user-search"
                        label="Service Center Short Name"
                        type="text"
                        placeholder="Enter Service Center Name"
                        name="servieCenterName"
                        register={register}
                        error={errors?.servieCenterName?.message?.toString()}
                      />
                    </div>
                  </div>
                  {isEditMode && (
                    <div className="flex justify-end items-center gap-4">
                      <button
                        className="w-24 h-10 border rounded-lg text-white font-bold tracking-wider bg-gbgc"
                        type="submit"
                        onClick={() => router.back()}
                      >
                        Update
                      </button>
                    </div>
                  )}
                  {isEditMode && (
                    <SecurityDetails
                      currentPassword={currentPassword}
                      password={""}
                      confirmPassword={""}
                      userId={userId[0]}
                    />
                  )}
                  {!isEditMode && (
                    <>
                      <div className="flex justify-items-center gap-4">
                        <div className="w-full">
                          <Input
                            preIcon="lock-closed"
                            label="Password"
                            type="password"
                            placeholder="Enter your Password"
                            name="password"
                            register={register}
                            error={errors?.password?.message?.toString()}
                          />
                        </div>
                        <div className="w-full">
                          <Input
                            preIcon="lock-closed"
                            label="Confirm Password"
                            type="password"
                            placeholder="Confirm your Password"
                            name="confirmPassword"
                            register={register}
                            error={errors?.confirmPassword?.message?.toString()}
                          />
                        </div>
                      </div>
                      <div className="mt-2 flex justify-end items-center gap-4">
                        <button
                          className="w-24 h-10 border rounded-lg text-white font-bold tracking-wider bg-gbgc"
                          type="submit"
                          onClick={() => router.back()}
                        >
                          Save
                        </button>
                      </div>
                    </>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      </form>
    </>
  );
}
